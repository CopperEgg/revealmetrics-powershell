﻿import-module .\CopperEGg.psd1
Initialize-MetricGroups
Start-CopperEggMonitor
